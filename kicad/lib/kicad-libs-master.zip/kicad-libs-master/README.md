# kicad-libraries
Personal collection of footprints &amp; symbols for kicad
